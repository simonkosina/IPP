<?php
/**
 * Súbor s definíciami návratových kódov.
 *
 * @author Simon Košina, xkosin09
 */

define("ERR_OK", 0);
define("ERR_PARAM", 10);
define("ERR_FOPEN_IN", 11);
define("ERR_FOPEN_OUT", 12);
define("ERR_FILE_MISSING", 41);
define("ERR_INTERNAL", 99);

?>